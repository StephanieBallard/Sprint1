//Stephanie Ballard

import UIKit

enum Size: Double {
    case small = 4.99
    case medium = 5.99
    case large = 6.99
}

struct Flavor {
    let name: String
    let rating: Double
}

struct Cone {
    let flavor: String
    let topping: String
    let size: Size
    
    func eat() {
        print("Mmm! I love \(flavor)")
    }
}

class IcecreamShop {
    var flavors: [Flavor]
    var sizes: [Size]
    var toppings: [String]
    var totalSales: Double
    
    init(flavors: [Flavor], sizes: [Size], toppings: [String], totalSales: Double) {
        self.flavors = flavors
        self.sizes = sizes
        self.toppings = toppings
        self.totalSales = totalSales
    }
    
    func orderCone (flavor: String, topping: String?, size: Size) -> Cone? {
        let newCone = Cone(flavor: flavor, topping: topping ?? "No topping", size: size)
        if let coneTopping = topping {
            print("The total for your cone with \(flavor) with \(coneTopping) comes to \(size.rawValue)")
            totalSales += newCone.size.rawValue
        }
        
        return newCone
    }
}

let coneOrder = Cone(flavor: "oreo", topping: "Cherry", size: Size.large)
let firstOrder = Cone(flavor: "Oreo", topping: "Cherry", size: Size.large)

let flavor1 = Flavor(name: "Chocolate", rating: 5.0)
let flavor2 = Flavor(name: "Strawberry", rating: 4.0)
let flavor3 = Flavor(name: "Vanilla", rating: 4.0)
let flavor4 = Flavor(name: "Oreo", rating: 4.5)
let flavor5 = Flavor(name: "Cotton Candy", rating: 5.0)
let flavor6 = Flavor(name: "Cookie Dough", rating: 4.5)
var flavors = [flavor1, flavor2, flavor3]
flavors.append(flavor4)
flavors.append(flavor5)
flavors.append(flavor6)
print(flavors[4])

let toppings = ["Whipped cream", "sprinkles", "Cherry"]

func listTopFlavors() {
    for flavor in flavors {
        if flavor.rating > 4.0 {
            print("One of our top flavors is \(flavor.name) ")
        }
    }
}
listTopFlavors()

let newFlavor1 = Flavor(name: "Rocky Road", rating: 3.7)
let newFlavor2 = Flavor(name: "Chocholate Chip Mint", rating: 4.5)
let newFlavor3 = Flavor(name: "Cookie Dough", rating: 4.2)
var newflavorsArray = [newFlavor1, newFlavor2, newFlavor3]
let sizesArray = [Size.small, Size.medium, Size.large]
let toppings1 = ["sprinkles", "gummy bears", "crushed oreos"]

let newIcecreamShop = IcecreamShop(flavors: newflavorsArray, sizes: sizesArray, toppings: toppings1, totalSales: 6.99)
listTopFlavors()
let newCone = Cone(flavor: "Cookie Dough", topping: "Sprinkles", size: Size.small)
newCone.eat()
print(newIcecreamShop.totalSales)
